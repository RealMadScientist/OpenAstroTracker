#include "../Configuration.hpp"
#include "Utility.hpp"
#include "WifiControl.hpp"
#include "MeadeCommandProcessor.hpp"
#include "Mount.hpp"

#if (WIFI_ENABLED == 1)

WifiControl::WifiControl(Mount *mount, LcdMenu *lcdMenu)
{
    _mount   = mount;
    _lcdMenu = lcdMenu;
    clearCmd();
}

void WifiControl::setup()
{
    LOG(DEBUG_WIFI, "[WIFI]: Starting up Wifi As Mode %d\n", WIFI_MODE);

    _cmdProcessor = MeadeCommandProcessor::instance();

    switch (WIFI_MODE)
    {
        case WIFI_MODE_INFRASTRUCTURE:  // startup Infrastructure Mode
            startInfrastructureMode();
            break;
        case WIFI_MODE_AP_ONLY:  // startup AP mode
            startAccessPointMode();
            break;
        case WIFI_MODE_ATTEMPT_INFRASTRUCTURE_FAIL_TO_AP:  // Attempt Infra, fail over to AP
            startInfrastructureMode();
            _infraStart = millis();
            break;
        case WIFI_MODE_DISABLED:  // Disabled
            WiFi.mode(WIFI_OFF);
            btStop();
            break;
    }
}

void WifiControl::startInfrastructureMode()
{
    LOG(DEBUG_WIFI, "[WIFI]: Starting Infrastructure Mode Wifi");
    LOG(DEBUG_WIFI, "[WIFI]:    with host name: %s", String(WIFI_HOSTNAME).c_str());
    LOG(DEBUG_WIFI, "[WIFI]:          for SSID: %s", String(WIFI_INFRASTRUCTURE_MODE_SSID).c_str());
    LOG(DEBUG_WIFI, "[WIFI]:       and WPA key: %s", String(WIFI_INFRASTRUCTURE_MODE_WPAKEY).c_str());

    #if defined(ESP32)
    WiFi.setHostname(WIFI_HOSTNAME);
    #endif
    WiFi.begin(WIFI_INFRASTRUCTURE_MODE_SSID, WIFI_INFRASTRUCTURE_MODE_WPAKEY);
}

void WifiControl::startAccessPointMode()
{
    LOG(DEBUG_WIFI, "[WIFI]: Starting AP Mode Wifi");
    IPAddress local_ip(192, 168, 1, 1);
    IPAddress gateway(192, 168, 1, 1);
    IPAddress subnet(255, 255, 255, 0);

    #if defined(ESP32)
    WiFi.setHostname(WIFI_HOSTNAME);
    #endif

    WiFi.mode(WIFI_AP);
    WiFi.softAPConfig(local_ip, gateway, subnet);
    if (!WiFi.softAP(WIFI_HOSTNAME, WIFI_AP_MODE_WPAKEY))
    {
        LOG(DEBUG_WIFI, "[WIFI]: AP mode could not be started!");
        return;
    }

    establishServers();
}

String wifiStatus(int status)
{
    if (status == WL_IDLE_STATUS)
        return "Idle.";
    if (status == WL_NO_SSID_AVAIL)
        return "No SSID available.";
    if (status == WL_SCAN_COMPLETED)
        return "Scan completed.";
    if (status == WL_CONNECTED)
        return "Connected!";
    if (status == WL_CONNECT_FAILED)
        return "Connect failed.";
    if (status == WL_CONNECTION_LOST)
        return "Connection Lost.";
    if (status == WL_DISCONNECTED)
        return "Disconnected.";
    return "Status " + String(status);
}

String WifiControl::getStatus()
{
    if (WIFI_MODE == WIFI_MODE_DISABLED)
    {
        return "0,";
    }

    String result = "1,";

    if (WIFI_MODE == WIFI_MODE_INFRASTRUCTURE)
    {
        result += "Infrastructure,";
    }
    else if (WIFI_MODE == WIFI_MODE_AP_ONLY)
    {
        result += "Access Point,";
    }
    else if (WIFI_MODE == WIFI_MODE_ATTEMPT_INFRASTRUCTURE_FAIL_TO_AP)
    {
        result += "Infra-Fail-To-AP,";
    }

    if (WIFI_MODE != WIFI_MODE_AP_ONLY)
    {
        result += wifiStatus(WiFi.status()) + ",";
    }
    #if defined(ESP32)
    result += WiFi.getHostname();
    result += ",";
    #endif

    result += getIP() + ":" + WIFI_PORT + ",";
    if (WIFI_MODE != WIFI_MODE_AP_ONLY)
    {
        result += String(WIFI_INFRASTRUCTURE_MODE_SSID) + ",";
    }
    result += String(WIFI_HOSTNAME);

    return result;
}

void WifiControl::establishServers()
{
    delete _tcpServer;
    _tcpServer = new WiFiServer(WIFI_PORT);
    _tcpServer->begin();
    _tcpServer->setNoDelay(true);

    delete _udp;
    _udp = new WiFiUDP();
    _udp->begin(WIFI_UDP_DISCOVERY_PORT);
}

String WifiControl::getIP()
{
    return WIFI_MODE == WIFI_MODE_DISABLED  ? "NONE"
           : WIFI_MODE == WIFI_MODE_AP_ONLY ? WiFi.softAPIP().toString()
                                            : WiFi.localIP().toString();
}

void WifiControl::clearCmd()
{
    _currCmd = "";
    _currCmd.reserve(_defaultCapacity);
}

void WifiControl::loop()
{
    if (WIFI_MODE == WIFI_MODE_DISABLED)
    {
        return;
    }

    if (WIFI_MODE != WIFI_MODE_AP_ONLY)
    {
        if (_status != WiFi.status())
        {
            _status = WiFi.status();
            LOG(DEBUG_WIFI, "[WIFI]: Connected status changed to %s", wifiStatus(_status).c_str());
            if (_status == WL_CONNECTED)
            {
                establishServers();
                LOG(DEBUG_WIFI,
                    "[WIFI]: Connecting to SSID %s at %s:%d",
                    WIFI_INFRASTRUCTURE_MODE_SSID,
                    WiFi.localIP().toString().c_str(),
                    WIFI_PORT);
            }
        }
        if (_status != WL_CONNECTED)
        {
            infraToAPFailover();
            return;
        }
    }

    _mount->loop();

    tcpLoop();
    udpLoop();
}

void WifiControl::infraToAPFailover()
{
    if (_infraStart != 0 && !WiFi.isConnected() && _infraStart + _infraWait < millis())
    {
        WiFi.disconnect();
        startAccessPointMode();
        _infraStart = 0;

        LOG(DEBUG_WIFI, "[WIFI]: Could not connect to Infra, Starting AP.");
    }
}

void WifiControl::tcpLoop()
{
    if (!_tcpServer)
        return;

    if (!client.connected())
    {
        if (_currCmd.length() != 0)
        {
            clearCmd();
        }
        client = _tcpServer->accept();
        if (!client.connected())
            return;
    }

    int avail;
    while ((avail = client.available()) != 0)
    {
        LOG(DEBUG_WIFI, "[WIFITCP]: Available bytes %d. Peeking.", avail);

        // Peek first byte and check for ACK (0x06) handshake
        if (_currCmd.length() == 0)
        {
            int peek = client.peek();
            LOG(DEBUG_WIFI, "[WIFITCP]: First byte is %x", peek);
            if (peek == 0x06)
            {
                client.read();
                LOG(DEBUG_WIFI, "[WIFITCP]: Query <-- Handshake request");
                client.write("P");
                LOG(DEBUG_WIFI, "[WIFITCP]: Reply --> P (polar mode)");
                _mount->loop();
            }
        }

        int recv;
        while ((recv = client.read()) != -1)
        {
            // Prevent newlines from polluting the command string
            if (recv == '\n' || recv == '\r')
            {
                _mount->loop();
                continue;
            }

            _currCmd += (char) recv;
            if (recv == '#')
            {
                LOG(DEBUG_WIFI, "[WIFITCP]: Query <-- %s", _currCmd.c_str());
                const char *retVal = _cmdProcessor->processCommand(_currCmd);

                if (retVal[0] != '\0')
                {
                    client.write(retVal);
                    LOG(DEBUG_WIFI, "[WIFITCP]: Reply --> %s", retVal);
                }
                else
                {
                    LOG(DEBUG_WIFI, "[WIFITCP]: No Reply");
                }
                clearCmd();
            }

            // Prevent memory overconsumption
            if (_currCmd.length() == _maxCapacity)
            {
                LOG(DEBUG_WIFI, "[WIFITCP]: Command string reached maximum capacity --> clear");
                clearCmd();
            }
            _mount->loop();
        }
    }
}

void WifiControl::udpLoop()
{
    if (!_udp)
        return;

    int packetSize = _udp->parsePacket();
    if (packetSize)
    {
        String lookingFor = "skyfi:";
        String reply      = "skyfi:";
        reply += WIFI_HOSTNAME;
        reply += "@";
        reply += getIP();
        LOG(DEBUG_WIFI,
            "[WIFIUDP]: Received %d bytes from %s, port %d",
            packetSize,
            _udp->remoteIP().toString().c_str(),
            _udp->remotePort());
        char incomingPacket[256];
        int len             = _udp->read(incomingPacket, sizeof(incomingPacket) - 1);
        incomingPacket[len] = 0;
        LOG(DEBUG_WIFI, "[WIFIUDP]: Received: %s", incomingPacket);

        incomingPacket[lookingFor.length()] = 0;
        if (lookingFor.equalsIgnoreCase(incomingPacket))
        {
            _udp->beginPacket(_udp->remoteIP(), WIFI_UDP_DISCOVERY_PORT);
            /*unsigned char bytes[255];
            reply.getBytes(bytes, 255);
            _udp->write(bytes, reply.length());*/

    #if defined(ESP32)
            _udp->print(reply.c_str());
    #endif

            _udp->endPacket();
            LOG(DEBUG_WIFI, "[WIFIUDP]: Replied: %s", reply.c_str());
        }
    }
}
#endif
