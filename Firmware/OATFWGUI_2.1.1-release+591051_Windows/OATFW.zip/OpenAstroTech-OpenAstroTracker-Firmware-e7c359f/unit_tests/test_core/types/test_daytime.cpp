#include <gtest/gtest.h>
#include "core/types/DayTime.hpp"

using core::DayTime;

TEST(DayTimeTest, DefaultConstructor)
{
    DayTime dt;
    EXPECT_EQ(0, dt.getTotalSeconds());
    EXPECT_EQ(0, dt.getHours());
    EXPECT_EQ(0, dt.getMinutes());
    EXPECT_EQ(0, dt.getSeconds());
}

TEST(DayTimeTest, HMSConstructor)
{
    DayTime dt(1, 30, 45);
    EXPECT_EQ(1, dt.getHours());
    EXPECT_EQ(30, dt.getMinutes());
    EXPECT_EQ(45, dt.getSeconds());
}

TEST(DayTimeTest, FloatConstructor)
{
    DayTime dt(1.5f);  // 1.5 hours = 1h 30m
    EXPECT_EQ(1, dt.getHours());
    EXPECT_EQ(30, dt.getMinutes());
    EXPECT_EQ(0, dt.getSeconds());
}

TEST(DayTimeTest, CopyConstructor)
{
    DayTime dt1(2, 15, 30);
    DayTime dt2(dt1);
    EXPECT_EQ(dt1.getTotalSeconds(), dt2.getTotalSeconds());
}

TEST(DayTimeTest, GetTotalHours)
{
    DayTime dt(2, 30, 0);
    EXPECT_FLOAT_EQ(2.5f, dt.getTotalHours());
}

TEST(DayTimeTest, GetTotalMinutes)
{
    DayTime dt(1, 30, 0);
    EXPECT_FLOAT_EQ(90.0f, dt.getTotalMinutes());
}

TEST(DayTimeTest, SetHMS)
{
    DayTime dt;
    dt.set(12, 34, 56);
    EXPECT_EQ(12, dt.getHours());
    EXPECT_EQ(34, dt.getMinutes());
    EXPECT_EQ(56, dt.getSeconds());
}

TEST(DayTimeTest, AddHours)
{
    DayTime dt(1, 0, 0);
    dt.addHours(2.5f);
    EXPECT_EQ(3, dt.getHours());
    EXPECT_EQ(30, dt.getMinutes());
}

TEST(DayTimeTest, AddMinutes)
{
    DayTime dt(0, 30, 0);
    dt.addMinutes(45);
    EXPECT_EQ(1, dt.getHours());
    EXPECT_EQ(15, dt.getMinutes());
}

TEST(DayTimeTest, AddSeconds)
{
    DayTime dt(0, 0, 30);
    dt.addSeconds(45);
    EXPECT_EQ(1, dt.getMinutes());
    EXPECT_EQ(15, dt.getSeconds());
}

TEST(DayTimeTest, AddTimeComponents)
{
    DayTime dt(1, 30, 0);
    dt.addTime(1, 45, 30);
    EXPECT_EQ(3, dt.getHours());
    EXPECT_EQ(15, dt.getMinutes());
    EXPECT_EQ(30, dt.getSeconds());
}

TEST(DayTimeTest, AddTimeObject)
{
    DayTime dt1(1, 0, 0);
    DayTime dt2(2, 30, 0);
    dt1.addTime(dt2);
    EXPECT_EQ(3, dt1.getHours());
    EXPECT_EQ(30, dt1.getMinutes());
}

TEST(DayTimeTest, SubtractTime)
{
    DayTime dt1(3, 0, 0);
    DayTime dt2(1, 30, 0);
    dt1.subtractTime(dt2);
    EXPECT_EQ(1, dt1.getHours());
    EXPECT_EQ(30, dt1.getMinutes());
}

TEST(DayTimeTest, WrapAt24Hours)
{
    DayTime dt(22, 0, 0);
    dt.addHours(4.0f);
    EXPECT_EQ(2, dt.getHours());
}

TEST(DayTimeTest, WrapNegative)
{
    DayTime dt(1, 0, 0);
    dt.subtractTime(DayTime(3, 0, 0));
    EXPECT_EQ(22, dt.getHours());
}

TEST(DayTimeTest, NegativeConstructor)
{
    // Constructor only uses sign of hours; abs() on hours, minutes as-is.
    // (-1, -30, 0) = -1 * ((60*1 + (-30))*60 + 0) = -1800 sec
    // getTime: labs(1800) => h=0, m=30, s=0, h*=sign(-1800)=0
    DayTime dt(-1, -30, -0);
    EXPECT_EQ(0, dt.getHours());
    EXPECT_EQ(30, dt.getMinutes());
    EXPECT_EQ(0, dt.getSeconds());
}

TEST(DayTimeTest, NegativeFloatConstructor)
{
    // -1.5h = -5400 sec => h=-1, m=30
    DayTime dt(-1.5f);
    EXPECT_EQ(-1, dt.getHours());
    EXPECT_EQ(30, dt.getMinutes());
}

TEST(DayTimeTest, SetWraps)
{
    // Constructor does NOT call checkHours(). set() does.
    DayTime dt(25, 0, 0);
    EXPECT_EQ(25, dt.getHours());
    // set() wraps
    dt.set(25, 0, 0);
    EXPECT_EQ(1, dt.getHours());
}

TEST(DayTimeTest, AddHoursNegative)
{
    DayTime dt(2, 0, 0);
    dt.addHours(-3.0f);
    EXPECT_EQ(23, dt.getHours());
}

TEST(DayTimeTest, GetTimeRef)
{
    DayTime dt(5, 15, 30);
    int h, m, s;
    dt.getTime(h, m, s);
    EXPECT_EQ(5, h);
    EXPECT_EQ(15, m);
    EXPECT_EQ(30, s);
}

TEST(DayTimeTest, GetTimeRefNegative)
{
    // (-2, -30, -15) = -1 * ((60*2 + (-30))*60 + (-15)) = -5385 sec
    // labs(5385): h=1, rem=1785, m=29, s=45, h*=-1 => (-1, 29, 45)
    DayTime dt(-2, -30, -15);
    int h, m, s;
    dt.getTime(h, m, s);
    EXPECT_EQ(-1, h);
    EXPECT_EQ(29, m);
    EXPECT_EQ(45, s);
}

TEST(DayTimeTest, NegativeHoursPositiveMinutesSeconds)
{
    // (-2, 31, 18): sign from hours only, abs on hours, minutes/seconds as-is
    // totalSeconds = -1 * ((60*2 + 31)*60 + 18) = -9078
    // getTime: labs(9078) => h=2, m=31, s=18, h*=sign(-9078)=-1 => (-2, 31, 18)
    DayTime dt(-2, 31, 18);
    EXPECT_EQ(-2, dt.getHours());
    EXPECT_EQ(31, dt.getMinutes());
    EXPECT_EQ(18, dt.getSeconds());
}

TEST(DayTimeTest, NegativeTotalMinutes)
{
    // (-2, 45, 0): totalSeconds = -1 * ((60*2 + 45)*60 + 0) = -9900
    // getTotalMinutes() = -9900 / 60 = -165
    DayTime dt(-2, 45, 0);
    EXPECT_EQ(-165.0f, dt.getTotalMinutes());
    EXPECT_EQ(-2, dt.getHours());
    EXPECT_EQ(45, dt.getMinutes());
    EXPECT_EQ(0, dt.getSeconds());
}

TEST(DayTimeTest, SetFromOther)
{
    DayTime dt1(5, 30, 15);
    DayTime dt2;
    dt2.set(dt1);
    EXPECT_EQ(5, dt2.getHours());
    EXPECT_EQ(30, dt2.getMinutes());
    EXPECT_EQ(15, dt2.getSeconds());
}

TEST(DayTimeTest, FormatStringExplicitSign)
{
    // Exercises the {+} macro: outputs '+' (or '-' if degs < 0)
    DayTime dt(5, 30, 15);
    char buf[32];
    dt.formatString(buf, "{+}{d}:{m}:{s}");
    // {+} emits '+' since degs >= 0, then {d} copies achDegs = "+05"
    EXPECT_EQ('+', buf[0]);
    EXPECT_NE('\0', buf[1]);
}

TEST(DayTimeTest, FormatStringCustomSecs)
{
    // Custom seconds pointer bypasses totalSeconds, enabling 100+ degs
    DayTime dt;
    char buf[32];
    long customSecs = 100L * 3600L + 30L * 60L + 15L;  // 100h 30m 15s
    dt.formatString(buf, "{d}:{m}:{s}", &customSecs);
    EXPECT_STREQ("+100:30:15", buf);
}

TEST(DayTimeTest, FormatStringCustomSecsNegative)
{
    // Negative custom seconds — sgn='-', degs=100 (labs)
    DayTime dt;
    char buf[32];
    long customSecs = -(100L * 3600L + 30L * 60L + 15L);
    dt.formatString(buf, "{d}:{m}:{s}", &customSecs);
    EXPECT_STREQ("-100:30:15", buf);
}

// ---------------------------------------------------------------------------
// joinSeconds — the inverse of splitSeconds, and the shared implementation of
// the DayTime(int, int, int) constructor.
// ---------------------------------------------------------------------------

TEST(DayTimeTest, JoinSeconds)
{
    EXPECT_EQ(0L, DayTime::joinSeconds(0, 0, 0));
    EXPECT_EQ(3600L, DayTime::joinSeconds(1, 0, 0));
    EXPECT_EQ(5445L, DayTime::joinSeconds(1, 30, 45));
    EXPECT_EQ(-5445L, DayTime::joinSeconds(-1, 30, 45));
}

TEST(DayTimeTest, JoinSecondsIsUsedByHMSConstructor)
{
    EXPECT_EQ(DayTime::joinSeconds(1, 30, 45), DayTime(1, 30, 45).getTotalSeconds());
    EXPECT_EQ(DayTime::joinSeconds(-2, 31, 18), DayTime(-2, 31, 18).getTotalSeconds());
    // Callers that pass negative minutes/seconds keep subtracting from the
    // magnitude, as NegativeConstructor and GetTimeRefNegative above rely on.
    EXPECT_EQ(DayTime::joinSeconds(-2, -30, -15), DayTime(-2, -30, -15).getTotalSeconds());
}

TEST(DayTimeTest, JoinSecondsInvertsSplitSeconds)
{
    // Skips (-3600, 0): splitSeconds reports h == 0 there, which drops the sign
    // (see JoinSecondsCannotSignSubHourValues).
    for (long secs = -180L * 3600L; secs <= 180L * 3600L; secs += 907L)
    {
        if ((secs < 0L) && (secs > -3600L))
        {
            continue;
        }
        int h, m, s;
        DayTime::splitSeconds(secs, h, m, s);
        EXPECT_EQ(secs, DayTime::joinSeconds(h, m, s)) << "secs=" << secs;
    }
}

TEST(DayTimeTest, JoinSecondsCannotSignSubHourValues)
{
    // Integer -0 is 0, so a value between -1 and 0 hours (or degrees) has no
    // way to express its sign through h. Both spellings join to the same
    // positive value; representing -00:30:00 needs a separate sign, not a
    // different join.
    EXPECT_EQ(1800L, DayTime::joinSeconds(0, 30, 0));
    EXPECT_EQ(1800L, DayTime::joinSeconds(-0, 30, 0));
}

TEST(DayTimeTest, JoinSecondsNegativeDegreesMoveAwayFromZero)
{
    // Declinations off the Meade wire: the sign sits on the degrees and the
    // minutes/seconds are unsigned magnitudes, so they must extend the value
    // away from zero. Adding them toward zero instead put :Sd-05*30:00# back
    // on the wire as -04*30:00 (see Declination::fromCelestialDegrees).
    EXPECT_EQ(-(5L * 3600L + 30L * 60L), DayTime::joinSeconds(-5, 30, 0));
    EXPECT_EQ(-(24L * 3600L + 23L * 60L), DayTime::joinSeconds(-24, 23, 0));
    EXPECT_EQ(-(69L * 3600L + 6L * 60L), DayTime::joinSeconds(-69, 6, 0));
    EXPECT_EQ(-(89L * 3600L + 59L * 60L + 59L), DayTime::joinSeconds(-89, 59, 59));
}
